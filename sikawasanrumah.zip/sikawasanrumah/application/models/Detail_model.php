<?php
class Detail_model extends CI_Model {
    public function get_detail_unit_kawasan() {
        // Join 'detail_unit' with 'kawasan' on 'kawasan_id'
        $this->db->select('detail_unit.*, kawasan.negara, kawasan.kota, kawasan.kecamatan, kawasan.google_map_url, kawasan.blok');
        $this->db->from('detail_unit');
        $this->db->join('kawasan', 'kawasan.id = detail_unit.kawasan_id');
        
        $query = $this->db->get();

        return $query->result();
    }
}
?>
