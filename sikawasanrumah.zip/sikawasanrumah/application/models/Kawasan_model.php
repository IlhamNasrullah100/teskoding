<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Kawasan_model extends CI_Model {
		
		function __construct() 
		{
			parent :: __construct();
		}
		
		public function get_kawasan()
		{
			$data = $this->db->query("SELECT * FROM kawasan");
			return $data->result();
		}



	

			public function get_all_kawasans() {
				$kawasans = $this->db->get('kawasan')->result();
		
				foreach ($kawasans as &$kawasan) {
					$detail_unit = $this->db
						->where('kawasan_id', $kawasan->id)
						->get('detail_unit')
						->result();
		
					$kawasan->detail_unit = $detail_unit;
				}
		
				return $kawasans;
			}
		
		




	





		
		public function get_edit_data($id)
		{
			$data = $this->db->query("SELECT * FROM kawasan WHERE id='$id'");
			return $data->result();
		}
		
		public function count_kawasan()
		{
			$data = $this->db->query("SELECT * FROM kawasan");
			return $data->num_rows();
		}
		
		public function simpan_data()
		{
			$data = array(
				'id'        => "",
				'negara'      => $this->input->post('negara'),
				'kota'       => $this->input->post('kota'),
				'kecamatan'     	=> $this->input->post('kecamatan'),
				'luas_tanah' => $this->input->post('luas_tanah'),
				'map'    	=> $this->input->post('map'),
				'blok'    	=> $this->input->post('blok'),
			);
			$this->db->insert('kawasan',$data);
			redirect('kawasan/index');
		}	
		
		public function edit()
		{
			$id = $this->input->post('id');
			$data = array(
				'id'        => "",
				'negara'      => $this->input->post('negara'),
				'kota'       => $this->input->post('kota'),
				'kecamatan'    => $this->input->post('kecamatan'),
				'luas_tanah' => $this->input->post('luas_tanah'),
				'map'    	=> $this->input->post('map'),
				'blok'    	=> $this->input->post('blok'),
			);
			
			$this->db->where('id',$id); 
			$this->db->update('kawasan',$data); 
			redirect('kawasan/index');
		}	
		
		public function hapus_data($id)
		{
			$this->db->query("DELETE FROM kawasan WHERE id='$id'");
			redirect('kawasan/index');
		}
	}
?>	