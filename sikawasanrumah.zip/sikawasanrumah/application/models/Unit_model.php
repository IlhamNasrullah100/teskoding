<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Unit_model extends CI_Model {
		
		function __construct() 
		{
			parent :: __construct();
            $this->load->database();
		}
		
		public function get_unit()
		{
			$data = $this->db->query("SELECT * FROM detail_unit");
			return $data->result();
		}

        public function get_all_detail_unit() {
            // Fetch all data from the 'detail_unit' table
            $query = $this->db->get('detail_unit');
            return $query->result();
        }
		
		public function get_edit_data($id)
		{
			$data = $this->db->query("SELECT * FROM detail_unit WHERE id='$id'");
			return $data->result();
		}
		
		public function count_unit()
		{
			$data = $this->db->query("SELECT * FROM detail_unit");
			return $data->num_rows();
		}
		
        public function save_data($no_rumah, $luas_tanah, $luas_bangunan, $harga, $tanggal_terjual, $file_name) {
            // Example: Save data to the 'units' table in the database
            $data = array(
                'no_rumah' => $no_rumah,
                'luas_tanah' => $luas_tanah,
                'luas_bangunan' => $luas_bangunan,
                'harga' => $harga,
                'tanggal_terjual' => $tanggal_terjual,
                'file_name' => $file_name
            );
    
            $this->db->insert('detail_unit', $data);
        }
    
        
        public function edit()
        {
            $id = $this->input->post('id');

            // Simpan data ke database
            $data = array(
                'kawasan_id' => $this->input->post('kawasan_id'),
                'no_rumah' => $this->input->post('no_rumah'),
                'luas_tanah' => $this->input->post('luas_tanah'),
                'luas_bangunan' => $this->input->post('luas_bangunan'),
                'harga' => $this->input->post('harga'),
                'tanggal_terjual' => $this->input->post('tanggal_terjual')
            );
        
            // Cek apakah ada file yang diupload
            if (!empty($_FILES['file_name']['name'])) {
                // Konfigurasi upload file
                $config['upload_path'] = './uploads/';
                $config['allowed_types'] = 'pdf';
                $config['max_size'] = 10240; // 10MB
        
                $this->load->library('upload', $config);
        
                // Lakukan upload file
                if ($this->upload->do_upload('file_name')) {
                    $file_data = $this->upload->data();
                    $data['file_name'] = $file_data['file_name'];
                    $data['file_path'] = $file_data['full_path'];
                } else {
                    // Jika upload gagal, tampilkan pesan error
                    $error = $this->upload->display_errors();
                    // Tambahkan kode untuk menangani error upload file
                }
            }
        
            $this->db->where('id', $id);
            $this->db->update('detail_unit', $data);
            redirect('unit');
}
		
		public function hapus_data($id)
		{
			$this->db->query("DELETE FROM detail_unit WHERE id='$id'");
			redirect('unit');
		}

      

        public function insert($data) {
            $this->db->insert('detail_unit', $data);
        }
        
	}
?>	