<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Kawasan</title>
</head>
<body>
    <h1>List Kawasan</h1>
    <table border="1">
        <thead>
            <tr>
                <th>ID Kawasan</th>
                <th>Luas Tanah</th>
                <th>Negara</th>
                <th>Kota</th>
                <th>Kecamatan</th>
                <th>Google Map URL</th>
                <th>Blok</th>
                <th>Detail Unit</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($kawasans as $kawasan): ?>
                <tr>
                    <td><?= $kawasan->id ?></td>
                    <td><?= $kawasan->luas_tanah ?></td>
                    <td><?= $kawasan->negara ?></td>
                    <td><?= $kawasan->kota ?></td>
                    <td><?= $kawasan->kecamatan ?></td>
                    <td><?= $kawasan->map ?></td>
                    <td><?= $kawasan->blok ?></td>
                    <td>
                        <?php foreach ($kawasan->detail_unit as $detail): ?>
                            <p>No Rumah: <?= $detail->no_rumah ?>, Luas Bangunan: <?= $detail->luas_bangunan ?>, Harga: <?= $detail->harga ?></p>
                        <?php endforeach; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
