
			<div class="main-content">
				<div class="container-fluid">
					<!-- OVERVIEW -->
					<div class="panel panel-headline">
						<div class="panel-heading">
							<h3 class="panel-title">Dashboard</h3>
							<p class="panel-subtitle">Period: <?php echo date('D, d M Y') ?></p>
						</div>
							<div class="metric">
							<h1 class="panel-title">Selamat Datang !</h1>
						</p>
					</div>
				</div>
			</div>