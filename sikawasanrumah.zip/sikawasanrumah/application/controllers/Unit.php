<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Unit extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
  
		$this->load->Model('Unit_model');
	}
	
	public function index() 
	{
		$data['unit'] = $this->Unit_model->get_unit();
		$data['c_unit']  = $this->Unit_model->count_unit();
		$this->load->view('sidebar', $data);
		$this->load->view('detailunit',$data);
		
	}
	
    
	// public function simpan_data() 
	// {
	// 	$this->Unit_model->simpan_data();
	// 	$data['unit'] = $this->Unit_model->get_unit();
	// 	$data['c_unit']  = $this->Unit_model->count_unit();
	// 	$this->load->view('detailunit',$data);
	// }
	
	public function edit_data($id) 
	{
		$data['data']   = $this->Unit_model->get_edit_data($id); 
		$data['unit']    = $this->Unit_model->get_unit();
		$data['c_unit']  = $this->Unit_model->count_unit();
		$this->load->view('sidebar', $data);
		$this->load->view('unit',$data);
	}
	
	public function edit() 
	{
		$this->Unit_model->edit(); 
	}
	
	public function hapus_data($id) 
	{
		$this->Unit_model->hapus_data($id);
	}

    public function simpan_data() {
        // Handle form submission
        // $this->Unit_model->simpan_data();
		// $data['unit'] = $this->Unit_model->get_unit();
		// $data['c_unit']  = $this->Unit_model->count_unit();
		// $this->load->view('detailunit',$data);
        $no_rumah = $this->input->post('no_rumah');
        $luas_tanah = $this->input->post('luas_tanah');
        $luas_bangunan = $this->input->post('luas_bangunan');
        $harga = $this->input->post('harga');
        $tanggal_terjual = $this->input->post('tanggal_terjual');

        // File upload configuration
        $config['upload_path'] = './uploads/'; // Specify the upload path
        $config['allowed_types'] = 'pdf'; // Specify allowed file types
        $config['max_size'] = 2048; // Specify max file size in KB

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('userfile')) {
            // Handle file upload error if any
            $error = array('error' => $this->upload->display_errors());
            print_r($error);
        } else {
            // File uploaded successfully
            $data = array('upload_data' => $this->upload->data());
            // You can do further processing here, e.g., saving data to the database
            // You can access the file details using $data['upload_data']
            
            // Example: Save data to the model
            $this->Unit_model->save_data($no_rumah, $luas_tanah, $luas_bangunan, $harga, $tanggal_terjual, $data['upload_data']['file_name']);

            // Redirect or display success message
            redirect('unit');
        }
    }
}
?>