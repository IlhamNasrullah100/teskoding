<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detail extends CI_Controller {

    public function index() {
        $this->load->model('Kawasan_model');
        $data['kawasans'] = $this->Kawasan_model->get_all_kawasans();

        $this->load->view('detail', $data);
    }

}
