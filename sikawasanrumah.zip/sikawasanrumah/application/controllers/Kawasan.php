<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kawasan extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		$this->load->Model('Kawasan_model');
	}
	
	public function index() 
	{
		$data['kawasan'] = $this->Kawasan_model->get_kawasan();
		$data['c_kawasan']  = $this->Kawasan_model->count_kawasan();
		$this->load->view('sidebar', $data);
		$this->load->view('index',$data);
		
	}
	
	public function simpan_data() 
	{
		$this->Kawasan_model->simpan_data();
		$data['kawasan'] = $this->Kawasan_model->get_kawasan();
		$data['c_kawasan']  = $this->Kawasan_model->count_kawasan();
		$this->load->view('index',$data);
	}
	
	public function edit_data($id) 
	{
		$data['data']   = $this->Kawasan_model->get_edit_data($id); 
		$data['kawasan']    = $this->Kawasan_model->get_kawasan();
		$data['c_kawasan']  = $this->Kawasan_model->count_kawasan();
		$this->load->view('sidebar', $data);
		$this->load->view('kawasan',$data);
	}
	
	public function edit() 
	{
		$this->Kawasan_model->edit(); 
	}
	
	public function hapus_data($id) 
	{
		$this->Kawasan_model->hapus_data($id);
	}
	
}
?>