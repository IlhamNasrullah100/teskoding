<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Upload_library
{
    protected $CI;

    public function __construct()
    {
        $this->CI =& get_instance();
        $this->CI->load->library('upload'); // Load the CodeIgniter upload library
    }

    public function do_upload($field)
    {
        $config['upload_path']   = './uploads/'; // Change this to your desired upload path
        $config['allowed_types'] = 'pdf'; // Add or modify allowed file types
        $config['max_size']      = 10240; // Set the maximum file size in kilobytes

        $this->CI->upload->initialize($config);

        if (!$this->CI->upload->do_upload($field)) {
            return array('error' => $this->CI->upload->display_errors());
        } else {
            return $this->CI->upload->data();
        }
    }
}
